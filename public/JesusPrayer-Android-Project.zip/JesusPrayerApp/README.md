# مشروع تطبيق صلاة يسوع للأندرويد (Jesus Prayer Android Project)

هذا المشروع يحتوي على تطبيق صلاة يسوع والصلوات السهمية بكامل ميزاته (React + Vite + PWA) مدمجاً ومحزماً داخل مشروع أندرويد متكامل يعمل بدون إنترنت (100% Offline).

---

## 🚀 كيفية استخراج ملف الـ APK (3 طرق سهلة):

### 1️⃣ الطريقة الأولى: البناء التلقائي عبر GitHub Actions (الأسهل بدون تثبيت أي برامج على جهازك)
1. قم بفك ضغط هذا المجلد وارفعه على حسابك في GitHub في مستودع جديد (Repository).
2. بمجرد رفع الملفات، ستعمل أداة GitHub Actions تلقائياً بفضل ملف `.github/workflows/build-apk.yml`.
3. ادخل على تبويب **Actions** في صفحة المستودع.
4. انتظر دقيقة واحدة حتى تكتمل العملية، ثم اضغط على البناء وحمّل ملف:
   `JesusPrayer-Debug-APK`
   وستجد داخله ملف `app-debug.apk` جاهزاً للتثبيت المباشر على أي هاتف أندرويد!

---

### 2️⃣ الطريقة الثانية: عبر Android Studio على الكمبيوتر
1. افتح برنامج Android Studio.
2. اختر **Open** ثم حدد مجلد `JesusPrayerApp`.
3. انتظر ثوانٍ حتى يقوم البرنامج بعمل مزامنة Gradle (Sync).
4. من القائمة العلوية اضغط على:
   `Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`.
5. سيظهر لك إشعار بالأسفل `APK(s) generated successfully`، اضغط على **locate** لتحصل على ملف الـ APK فوراً.

---

### 3️⃣ الطريقة الثالثة: عبر سطر الأوامر (Terminal / Command Prompt)
- على نظام لينكس أو ماك:
  ```bash
  chmod +x gradlew
  ./gradlew assembleDebug
  ```
- على نظام ويندوز:
  ```cmd
  gradlew.bat assembleDebug
  ```
ستجد ملف الـ APK في المسار:
`app/build/outputs/apk/debug/app-debug.apk`
