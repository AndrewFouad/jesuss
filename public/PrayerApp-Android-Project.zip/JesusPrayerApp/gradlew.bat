@rem Gradle startup script for Windows
@echo off
set CLASSPATH="gradle\wrapper\gradle-wrapper.jar"
java -jar "%CLASSPATH%" %*
